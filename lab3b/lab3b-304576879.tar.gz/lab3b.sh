#VINCENT CHI 304576879 vincentchi9702@gmail.com                                                                                                                                    
#!/bin/bash                                                                                                                                                                        
python lab3b.py $@
